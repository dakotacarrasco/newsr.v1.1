#!/usr/bin/env python3
"""
CityDigest - A modular local news digest system
"""

__version__ = "0.1.0"
__author__ = "Dakota Carrasco" 