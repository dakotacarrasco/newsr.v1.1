#!/usr/bin/env python3
import os
import smtplib
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import logging
import traceback
from typing import List, Dict, Any, Optional

logger = logging.getLogger("citydigest_notifications")

def send_email_notification(subject, message, recipient=None):
    """Send an email notification for errors"""
    try:
        # Default Gmail settings
        default_smtp_server = "smtp.gmail.com"
        default_smtp_port = 587
        default_smtp_user = "dakotacarrasco98@gmail.com"  # Replace with your actual Gmail
        default_smtp_password = "odxr iqhk hwar lfjg"  # Replace with your actual App Password
        default_sender = "dakotacarrasco98@gmail.com"  # Replace with your actual Gmail
        default_recipient = "dakota@newsr.io"  # Replace with your actual Gmail
        
        # Get email settings from environment variables, falling back to defaults
        smtp_server = os.environ.get("SMTP_SERVER", default_smtp_server)
        smtp_port = int(os.environ.get("SMTP_PORT", default_smtp_port))
        smtp_user = os.environ.get("SMTP_USER", default_smtp_user)
        smtp_password = os.environ.get("SMTP_PASSWORD", default_smtp_password)
        sender = os.environ.get("NOTIFICATION_SENDER", default_sender)
        recipient = recipient or os.environ.get("NOTIFICATION_RECIPIENT", default_recipient)
        
        # Create message
        msg = MIMEMultipart()
        msg["From"] = sender
        msg["To"] = recipient
        msg["Subject"] = f"CityDigest Alert: {subject}"
        
        # Add timestamp and host information
        full_message = f"""
        Timestamp: {datetime.now().isoformat()}
        Server: {os.uname().nodename if hasattr(os, 'uname') else 'Unknown'}
        
        {message}
        """
        
        msg.attach(MIMEText(full_message, "plain"))
        
        # Send email
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_user, smtp_password)
            server.send_message(msg)
        
        logger.info(f"Sent notification email to {recipient}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to send email notification: {str(e)}")
        return False

def send_daily_digest_report(created_digests: List[Dict[str, Any]]):
    """Send a daily report of all created digests
    
    Args:
        created_digests: List of digest information dictionaries
    """
    if not created_digests:
        logger.info("No digests to report")
        return
    
    subject = f"CityDigest Daily Report: {datetime.now().strftime('%Y-%m-%d')}"
    
    # Format the message with digest details
    message = "Daily Digest Creation Report\n\n"
    message += f"Total digests created: {len(created_digests)}\n\n"
    
    for i, digest in enumerate(created_digests, 1):
        city_name = digest.get('city_name', 'Unknown')
        region = digest.get('region', 'Unknown')
        article_count = digest.get('article_count', 0)
        status = digest.get('status', 'unknown')
        
        message += f"{i}. {city_name}, {region}\n"
        message += f"   Articles: {article_count}\n"
        message += f"   Status: {status}\n"
        message += f"   Date: {digest.get('date', 'Unknown')}\n"
        
        # Add headline if available
        if digest.get('headline'):
            message += f"   Headline: {digest['headline']}\n"
            
        message += "\n"
    
    send_email_notification(subject, message)

def send_error_notification(error: Exception, context: str = "Unknown context"):
    """Send notification about an error
    
    Args:
        error: The exception that occurred
        context: Information about where the error occurred
    """
    subject = f"CityDigest Error: {context}"
    
    message = f"An error occurred in CityDigest: {context}\n\n"
    message += f"Error Type: {type(error).__name__}\n"
    message += f"Error Message: {str(error)}\n\n"
    message += f"Traceback:\n{traceback.format_exc()}"
    
    send_email_notification(subject, message)

def send_shutdown_notification(reason: str = "Unknown reason"):
    """Send notification about a system shutdown
    
    Args:
        reason: The reason for the shutdown
    """
    subject = "CityDigest System Shutdown"
    
    message = f"The CityDigest system has shut down.\n\n"
    message += f"Reason: {reason}\n"
    message += f"Time: {datetime.now().isoformat()}\n"
    
    send_email_notification(subject, message)

def send_startup_notification():
    """Send notification when the system starts up"""
    subject = "CityDigest System Started"
    
    message = f"The CityDigest system has started.\n\n"
    message += f"Time: {datetime.now().isoformat()}\n"
    
    # Add environment information
    message += "\nEnvironment Information:\n"
    message += f"Python Version: {os.sys.version}\n"
    message += f"Server: {os.uname().nodename if hasattr(os, 'uname') else 'Unknown'}\n"
    
    # Add configuration status
    supabase_url = os.environ.get("SUPABASE_URL", "Not configured")
    supabase_status = "Configured" if os.environ.get("SUPABASE_SERVICE_KEY") else "Not configured"
    openai_status = "Configured" if os.environ.get("OPENAI_API_KEY") else "Not configured"
    mixtral_status = "Configured" if os.environ.get("MIXTRAL_API_KEY") else "Not configured"
    
    message += f"Supabase URL: {supabase_url}\n"
    message += f"Supabase Auth: {supabase_status}\n"
    message += f"OpenAI API: {openai_status}\n"
    message += f"Mixtral API: {mixtral_status}\n"
    
    send_email_notification(subject, message) 